const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  PutCommand,
  DeleteCommand,
  ScanCommand,
} = require("@aws-sdk/lib-dynamodb");
const fs = require("fs");
const path = require("path");

const client = new DynamoDBClient({ region: "af-south-1" });
const docClient = DynamoDBDocumentClient.from(client);

const TABLE_NAME = process.env.TABLE_NAME || "exam-platform-data-dev";

/**
 * Read and parse the JSON file, fixing smart quotes
 */
function readQuestionsFromFile() {
  console.log("📖 Reading questions from JSON file...");

  const filePath = path.join(__dirname, "seed-re5-exam_premium_pro_enhanced.json");

  try {
    const content = fs.readFileSync(filePath, "utf8");
    const questions = JSON.parse(content);
    console.log(`✅ Successfully parsed ${questions.length} questions`);
    return questions;
  } catch (error) {
    console.error("❌ Error parsing JSON:", error.message);
    throw error;
  }
}

/**
 * Delete all existing Premium/Pro questions from the question bank
 */
async function deleteExistingPremiumProQuestions() {
  console.log("🗑️  Deleting existing Premium/Pro questions...");

  try {
    // Scan for all questions in the QUESTIONBANK
    const scanCommand = new ScanCommand({
      TableName: TABLE_NAME,
      FilterExpression: "PK = :pk",
      ExpressionAttributeValues: {
        ":pk": "QUESTIONBANK",
      },
    });

    const result = await docClient.send(scanCommand);

    if (result.Items && result.Items.length > 0) {
      console.log(`Found ${result.Items.length} existing questions to delete`);

      // Delete each item
      for (const item of result.Items) {
        console.log(`Deleting: ${item.SK}`);
        const deleteCommand = new DeleteCommand({
          TableName: TABLE_NAME,
          Key: {
            PK: item.PK,
            SK: item.SK,
          },
        });
        await docClient.send(deleteCommand);
      }

      console.log("✅ All existing Premium/Pro questions deleted");
    } else {
      console.log("No existing Premium/Pro questions found");
    }
  } catch (error) {
    console.error("Error deleting existing data:", error);
    throw error;
  }
}

/**
 * Map cognitive level to difficulty
 */
function mapCognitiveToDifficulty(cognitiveLevel) {
  if (cognitiveLevel.includes("Level 1") || cognitiveLevel.includes("Knowledge")) {
    return "beginner";
  } else if (cognitiveLevel.includes("Level 2") || cognitiveLevel.includes("Comprehension")) {
    return "beginner";
  } else if (cognitiveLevel.includes("Level 3") || cognitiveLevel.includes("Application")) {
    return "intermediate";
  } else if (cognitiveLevel.includes("Level 4") || cognitiveLevel.includes("Analysis")) {
    return "advanced";
  } else if (cognitiveLevel.includes("Level 5") || cognitiveLevel.includes("Synthesis")) {
    return "advanced";
  } else if (cognitiveLevel.includes("Level 6") || cognitiveLevel.includes("Evaluation")) {
    return "advanced";
  }
  return "intermediate";
}

/**
 * Convert question data to DynamoDB format
 */
function convertQuestionToDynamoDBFormat(question) {
  const questionId = `RE5-${question.ID.toString().padStart(4, "0")}`;

  // Map correct answer letter to option
  const correctAnswerMap = {
    A: "a",
    B: "b",
    C: "c",
    D: "d",
  };

  const correctAnswerId = correctAnswerMap[question.Correct_Answer];

  return {
    PK: "QUESTIONBANK",
    SK: `QUESTION#${questionId}`,
    GSI1PK: `QUESTION#CATEGORY#${question.Task_Category}`,
    GSI1SK: `${question.Cognitive_Level}#${questionId}`,
    GSI3PK: "QUESTION#ALL",
    GSI3SK: questionId,

    questionId,
    questionNumber: question.ID,
    questionText: question.Question_Stem,
    questionType: "single", // All questions appear to be single choice

    // Format options as array of objects
    options: [
      {
        id: "a",
        text: question.Option_A,
        isCorrect: correctAnswerId === "a",
      },
      {
        id: "b",
        text: question.Option_B,
        isCorrect: correctAnswerId === "b",
      },
      {
        id: "c",
        text: question.Option_C,
        isCorrect: correctAnswerId === "c",
      },
      {
        id: "d",
        text: question.Option_D,
        isCorrect: correctAnswerId === "d",
      },
    ],

    correctAnswer: correctAnswerId,
    explanation: question.Explanation,

    // Metadata
    taskCategory: question.Task_Category,
    qcId: question.QC_ID,
    legislativeAnchor: question.Legislative_Anchor,
    cognitiveLevel: question.Cognitive_Level,
    topic: question.Topic,

    // Tier access - Premium and Pro only
    tierAccess: ["premium", "pro"],
    isPremiumQuestion: true,

    // Additional fields
    category: question.Task_Category,
    difficulty: mapCognitiveToDifficulty(question.Cognitive_Level),
    points: 10,

    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: "admin",
    status: "active",
    entityType: "QUESTION",
  };
}

/**
 * Import questions to DynamoDB
 */
async function importQuestions(questions) {
  console.log("📝 Importing questions to DynamoDB...");

  let imported = 0;
  const errors = [];

  for (const question of questions) {
    try {
      const questionItem = convertQuestionToDynamoDBFormat(question);

      const command = new PutCommand({
        TableName: TABLE_NAME,
        Item: questionItem,
      });

      await docClient.send(command);
      imported++;

      if (imported % 100 === 0) {
        console.log(`✅ Imported ${imported}/${questions.length} questions...`);
      }
    } catch (error) {
      console.error(`Error importing question ${question.ID}:`, error);
      errors.push(`Question ${question.ID}: ${error.message}`);
    }
  }

  console.log(`✅ Successfully imported ${imported}/${questions.length} questions`);

  if (errors.length > 0) {
    console.log(`⚠️  ${errors.length} errors occurred:`);
    errors.forEach((error) => console.log(`  - ${error}`));
  }

  return { imported, errors };
}

/**
 * Main function
 */
async function main() {
  console.log("🚀 Starting Premium/Pro Question Import Script");
  console.log(`📊 Table: ${TABLE_NAME}`);
  console.log("");

  try {
    // Step 1: Read questions from file
    const questions = readQuestionsFromFile();
    console.log("");

    // Step 2: Delete existing Premium/Pro questions
    await deleteExistingPremiumProQuestions();
    console.log("");

    // Step 3: Import new questions
    const result = await importQuestions(questions);
    console.log("");

    console.log("🎉 Import script completed successfully!");
    console.log("");
    console.log("📊 Summary:");
    console.log(`   - Total questions in file: ${questions.length}`);
    console.log(`   - Successfully imported: ${result.imported}`);
    console.log(`   - Errors: ${result.errors.length}`);
    console.log("");
    console.log("✨ Premium and Pro users can now access these questions in the quiz builder");
  } catch (error) {
    console.error("❌ Script failed:", error);
    process.exit(1);
  }
}

main();
