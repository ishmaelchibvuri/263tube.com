"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: "af-south-1" });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const TABLE_NAME = process.env["TABLE_NAME"] || "exam-platform-data-dev";
const EXAM_ID = "re5-free-exam"; // FREE TIER ONLY EXAM
// Exam metadata
const examMetadata = {
    PK: `EXAM#${EXAM_ID}`,
    SK: "METADATA",
    GSI1PK: "EXAM#ACTIVE",
    GSI1SK: `RE5#${new Date().toISOString()}`,
    GSI3PK: `EXAM#CATEGORY#RE5`,
    GSI3SK: `intermediate#${EXAM_ID}`,
    examId: EXAM_ID,
    title: "RE5 Full Exam Simulation",
    description: "Complete RE5 Regulatory Examination simulation covering all sections of the South African financial services regulatory framework.",
    category: "RE5",
    difficulty: "intermediate",
    totalQuestions: 50,
    totalTime: 7200, // 2 hours in seconds
    duration: 7200,
    passingScore: 70,
    pointsPerQuestion: 2,
    isActive: true,
    // TIER RESTRICTION: This exam is exclusively for free tier users
    // Premium/Pro users get randomly generated exams instead
    allowedTiers: ["free"],
    isFreeExam: true,
    createdBy: "admin",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    entityType: "EXAM",
};
// 50 RE5 Questions - FREE TIER ONLY
// These questions are exclusively for free tier users
// Premium/Pro users will use the full 1000-question bank via custom quiz builder
const questions = [
    {
        questionNumber: 1,
        questionText: "What is the primary objective of the Financial Advisory and Intermediary Services Act (FAIS Act)?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To regulate tax collection in South Africa",
                isCorrect: false,
            },
            {
                id: "b",
                text: "To protect consumers of financial services and ensure the professional and ethical standards of financial service providers",
                isCorrect: true,
            },
            {
                id: "c",
                text: "To manage the national budget",
                isCorrect: false,
            },
            {
                id: "d",
                text: "To regulate imports and exports",
                isCorrect: false,
            },
        ],
        explanation: "The FAIS Act aims to regulate financial advisory and intermediary services to protect consumers and ensure professional standards.",
        points: 5,
        categories: ["FAIS Act", "Legislation"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 2,
        questionText: "Under FICA, what is the main purpose of Customer Due Diligence (CDD)?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To verify the identity of clients and assess money laundering risks",
                isCorrect: true,
            },
            {
                id: "b",
                text: "To determine investment preferences",
                isCorrect: false,
            },
            { id: "c", text: "To calculate tax obligations", isCorrect: false },
            {
                id: "d",
                text: "To market additional products",
                isCorrect: false,
            },
        ],
        explanation: "Customer Due Diligence under FICA is designed to verify client identity and assess money laundering and terrorist financing risks.",
        points: 5,
        categories: ["FICA", "Compliance", "Anti-Money Laundering"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 3,
        questionText: "Which of the following is NOT one of the General Code of Conduct requirements under the FAIS Act?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Act with honesty and integrity",
                isCorrect: false,
            },
            {
                id: "b",
                text: "Always recommend the most expensive product",
                isCorrect: true,
            },
            {
                id: "c",
                text: "Provide advice that is appropriate to client needs",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Avoid conflicts of interest",
                isCorrect: false,
            },
        ],
        explanation: "The General Code of Conduct requires acting in client's best interests, not recommending the most expensive product.",
        points: 5,
        categories: ["FAIS Act", "Ethics", "Code of Conduct"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 4,
        questionText: "What is the maximum period within which a Financial Services Provider (FSP) must respond to a client complaint?",
        questionType: "single",
        options: [
            { id: "a", text: "14 days", isCorrect: false },
            { id: "b", text: "30 days", isCorrect: false },
            { id: "c", text: "6 weeks", isCorrect: true },
            { id: "d", text: "3 months", isCorrect: false },
        ],
        explanation: "Under FAIS regulations, an FSP must respond to a client complaint within 6 weeks of receipt.",
        points: 5,
        categories: ["FAIS Act", "Complaints Management", "Compliance"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 5,
        questionText: "Which body is responsible for supervising compliance with the FAIS Act?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "South African Reserve Bank (SARB)",
                isCorrect: false,
            },
            {
                id: "b",
                text: "Financial Sector Conduct Authority (FSCA)",
                isCorrect: true,
            },
            {
                id: "c",
                text: "National Treasury",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Companies and Intellectual Property Commission (CIPC)",
                isCorrect: false,
            },
        ],
        explanation: "The FSCA (formerly FSB) is responsible for supervising compliance with the FAIS Act.",
        points: 5,
        categories: ["FAIS Act", "Regulatory Bodies", "Legislation"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 6,
        questionText: "What type of information must be disclosed to a client BEFORE providing financial advice?",
        questionType: "multiple",
        options: [
            {
                id: "a",
                text: "FSP license details and contact information",
                isCorrect: true,
            },
            {
                id: "b",
                text: "Remuneration and fees structure",
                isCorrect: true,
            },
            {
                id: "c",
                text: "Conflicts of interest",
                isCorrect: true,
            },
            {
                id: "d",
                text: "Personal investment portfolio",
                isCorrect: false,
            },
        ],
        explanation: "FSPs must disclose license details, fees, and conflicts of interest before providing advice, but not their personal investments.",
        points: 5,
        categories: ["FAIS Act", "Disclosure", "Ethics"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 7,
        questionText: "Under FICA, when must Enhanced Due Diligence (EDD) be applied?",
        questionType: "single",
        options: [
            { id: "a", text: "For all clients without exception", isCorrect: false },
            {
                id: "b",
                text: "Only for high-risk clients or transactions",
                isCorrect: true,
            },
            {
                id: "c",
                text: "Only for corporate clients",
                isCorrect: false,
            },
            {
                id: "d",
                text: "FICA does not require EDD",
                isCorrect: false,
            },
        ],
        explanation: "Enhanced Due Diligence is required for high-risk clients, transactions, or business relationships under FICA.",
        points: 5,
        categories: ["FICA", "Risk Management", "Compliance"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 8,
        questionText: "What is the meaning of 'Know Your Client' (KYC) in financial services?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Marketing strategy to personalize communication",
                isCorrect: false,
            },
            {
                id: "b",
                text: "Process of verifying client identity and understanding their financial needs and risk profile",
                isCorrect: true,
            },
            {
                id: "c",
                text: "Social media strategy",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Customer satisfaction survey",
                isCorrect: false,
            },
        ],
        explanation: "KYC involves verifying client identity and understanding their financial needs, objectives, and risk tolerance.",
        points: 5,
        categories: ["Client Onboarding", "KYC", "Best Practices"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 9,
        questionText: "Which of the following is a Politically Exposed Person (PEP) under FICA?",
        questionType: "single",
        options: [
            { id: "a", text: "Any government employee", isCorrect: false },
            {
                id: "b",
                text: "Individuals holding prominent public positions who may be at higher risk of corruption",
                isCorrect: true,
            },
            {
                id: "c",
                text: "All politicians regardless of position",
                isCorrect: false,
            },
            { id: "d", text: "Corporate executives only", isCorrect: false },
        ],
        explanation: "PEPs are individuals in prominent public positions with higher corruption risk requiring enhanced scrutiny.",
        points: 5,
        categories: ["FICA", "Risk Management", "PEPs"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 10,
        questionText: "What is the minimum CPD (Continuing Professional Development) requirement for FSPs per year?",
        questionType: "single",
        options: [
            { id: "a", text: "10 hours", isCorrect: false },
            { id: "b", text: "15 hours", isCorrect: false },
            { id: "c", text: "20 hours", isCorrect: true },
            { id: "d", text: "30 hours", isCorrect: false },
        ],
        explanation: "FSPs are required to complete at least 20 hours of relevant CPD activities per year.",
        points: 5,
        categories: ["Professional Development", "FAIS Act", "Compliance"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 11,
        questionText: "What is the consequence of providing financial advice without a valid FSP license?",
        questionType: "single",
        options: [
            { id: "a", text: "A warning letter only", isCorrect: false },
            { id: "b", text: "No consequences", isCorrect: false },
            {
                id: "c",
                text: "Criminal offense with potential fine and imprisonment",
                isCorrect: true,
            },
            { id: "d", text: "Only civil penalties", isCorrect: false },
        ],
        explanation: "Operating without an FSP license is a criminal offense under the FAIS Act with severe penalties including fines and imprisonment.",
        points: 5,
        categories: ["FAIS Act", "Licensing", "Compliance"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 12,
        questionText: "Which document must be provided to a client after financial advice is given?",
        questionType: "single",
        options: [
            { id: "a", text: "Marketing brochure", isCorrect: false },
            { id: "b", text: "Record of Advice (ROA)", isCorrect: true },
            { id: "c", text: "Company annual report", isCorrect: false },
            { id: "d", text: "Investment dictionary", isCorrect: false },
        ],
        explanation: "A Record of Advice documenting the advice provided and reasons must be given to the client.",
        points: 5,
        categories: ["FAIS Act", "Documentation", "Compliance"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 13,
        questionText: "Under FICA, suspicious transactions must be reported to which authority?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Financial Intelligence Centre (FIC)",
                isCorrect: true,
            },
            {
                id: "b",
                text: "South African Police Service",
                isCorrect: false,
            },
            { id: "c", text: "National Treasury", isCorrect: false },
            { id: "d", text: "Local municipality", isCorrect: false },
        ],
        explanation: "Suspicious transaction reports must be submitted to the Financial Intelligence Centre.",
        points: 5,
        categories: ["FICA", "Compliance", "Reporting"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 14,
        questionText: "What is 'tipping off' in the context of money laundering regulations?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Providing investment tips to clients",
                isCorrect: false,
            },
            {
                id: "b",
                text: "Informing a client that a suspicious transaction report has been filed about them",
                isCorrect: true,
            },
            { id: "c", text: "Sharing market insights", isCorrect: false },
            {
                id: "d",
                text: "Giving bonuses to staff",
                isCorrect: false,
            },
        ],
        explanation: "Tipping off is illegally informing someone that they are under investigation or a report has been filed, which is prohibited under FICA.",
        points: 5,
        categories: ["FICA", "Anti-Money Laundering", "Compliance"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 15,
        questionText: "What is the primary purpose of a Financial Needs Analysis (FNA)?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To sell as many products as possible",
                isCorrect: false,
            },
            {
                id: "b",
                text: "To understand client's financial situation, needs, and objectives to provide appropriate advice",
                isCorrect: true,
            },
            { id: "c", text: "To comply with tax laws", isCorrect: false },
            {
                id: "d",
                text: "To determine client's social media presence",
                isCorrect: false,
            },
        ],
        explanation: "An FNA is conducted to understand the client's circumstances and provide suitable financial advice.",
        points: 5,
        categories: ["Client Onboarding", "Best Practices", "FAIS Act"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 16,
        questionText: "Which of the following represents a conflict of interest that must be disclosed?",
        questionType: "multiple",
        options: [
            {
                id: "a",
                text: "Receiving commission from product providers",
                isCorrect: true,
            },
            {
                id: "b",
                text: "Having ownership interest in recommended products",
                isCorrect: true,
            },
            {
                id: "c",
                text: "Being a qualified financial advisor",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Having relationships with product providers that may influence advice",
                isCorrect: true,
            },
        ],
        explanation: "All financial interests and relationships that could influence advice must be disclosed as potential conflicts of interest.",
        points: 5,
        categories: ["Ethics", "Conflicts of Interest", "FAIS Act"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 17,
        questionText: "How long must FSPs retain records of financial advice provided to clients?",
        questionType: "single",
        options: [
            { id: "a", text: "1 year", isCorrect: false },
            { id: "b", text: "3 years", isCorrect: false },
            { id: "c", text: "5 years", isCorrect: true },
            { id: "d", text: "10 years", isCorrect: false },
        ],
        explanation: "FAIS regulations require FSPs to retain records of advice for at least 5 years.",
        points: 5,
        categories: ["Record Keeping", "FAIS Act", "Compliance"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 18,
        questionText: "What is the role of a Key Individual in an FSP organization?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To manage the company's finances only",
                isCorrect: false,
            },
            {
                id: "b",
                text: "To oversee and ensure compliance with FAIS Act requirements",
                isCorrect: true,
            },
            { id: "c", text: "To handle marketing campaigns", isCorrect: false },
            { id: "d", text: "To recruit new staff members", isCorrect: false },
        ],
        explanation: "A Key Individual is responsible for ensuring the FSP complies with all FAIS Act requirements and regulations.",
        points: 5,
        categories: ["FAIS Act", "Organizational Structure", "Compliance"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 19,
        questionText: "Which of the following best describes 'fit and proper' requirements for FSPs?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Physical fitness standards",
                isCorrect: false,
            },
            {
                id: "b",
                text: "Requirements related to honesty, integrity, competence, and financial soundness",
                isCorrect: true,
            },
            { id: "c", text: "Dress code requirements", isCorrect: false },
            {
                id: "d",
                text: "Office location standards",
                isCorrect: false,
            },
        ],
        explanation: "Fit and proper requirements assess whether individuals have the necessary integrity, competence, and financial standing to provide financial services.",
        points: 5,
        categories: ["FAIS Act", "Licensing", "Professionalism"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 20,
        questionText: "What is the maximum cash threshold above which a transaction must be reported under FICA?",
        questionType: "single",
        options: [
            { id: "a", text: "R10,000", isCorrect: false },
            { id: "b", text: "R24,999.99", isCorrect: true },
            { id: "c", text: "R50,000", isCorrect: false },
            { id: "d", text: "R100,000", isCorrect: false },
        ],
        explanation: "Cash transactions of R25,000 or more must be reported to the Financial Intelligence Centre under FICA regulations.",
        points: 5,
        categories: ["FICA", "Compliance", "Reporting"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 21,
        questionText: "What is the role of the Ombud for Financial Services Providers?",
        questionType: "single",
        options: [
            { id: "a", text: "To issue FSP licenses", isCorrect: false },
            {
                id: "b",
                text: "To resolve disputes between consumers and FSPs through mediation",
                isCorrect: true,
            },
            { id: "c", text: "To collect taxes from FSPs", isCorrect: false },
            { id: "d", text: "To regulate stock exchanges", isCorrect: false },
        ],
        explanation: "The Ombud for Financial Services Providers provides an independent dispute resolution service for complaints against FSPs.",
        points: 5,
        categories: ["Regulatory Bodies", "Complaints Management", "FAIS Act"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 22,
        questionText: "Under the Treating Customers Fairly (TCF) principles, which outcome focuses on product suitability?",
        questionType: "single",
        options: [
            { id: "a", text: "Outcome 1: Fair culture", isCorrect: false },
            { id: "b", text: "Outcome 3: Suitable advice", isCorrect: false },
            {
                id: "c",
                text: "Outcome 4: Products and services meet needs",
                isCorrect: true,
            },
            {
                id: "d",
                text: "Outcome 6: No unreasonable barriers",
                isCorrect: false,
            },
        ],
        explanation: "TCF Outcome 4 ensures that products and services marketed and sold in the retail market are designed to meet the needs of identified customer groups.",
        points: 5,
        categories: ["TCF", "Consumer Protection", "Product Suitability"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 23,
        questionText: "Which of the following is a Category I financial product under FAIS?",
        questionType: "single",
        options: [
            { id: "a", text: "Long-term insurance (Category A)", isCorrect: true },
            { id: "b", text: "Retail pension benefits", isCorrect: false },
            { id: "c", text: "Friendly society benefits", isCorrect: false },
            { id: "d", text: "Bargaining council benefits", isCorrect: false },
        ],
        explanation: "Category I products include long-term insurance (Category A), which requires specific competency and licensing.",
        points: 5,
        categories: ["FAIS Act", "Product Classification", "Licensing"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 24,
        questionText: "What does POPIA stand for and what is its main purpose?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Protection of Personal Information Act - to protect personal information",
                isCorrect: true,
            },
            {
                id: "b",
                text: "Prevention of Organized Crime Act - to fight organized crime",
                isCorrect: false,
            },
            {
                id: "c",
                text: "Public Order and Prevention Act - to maintain public order",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Professional Organizations and Practices Act - to regulate professions",
                isCorrect: false,
            },
        ],
        explanation: "POPIA (Protection of Personal Information Act) regulates how personal information must be processed, ensuring privacy rights.",
        points: 5,
        categories: ["POPIA", "Data Protection", "Privacy", "Legislation"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 25,
        questionText: "Under POPIA, what is the maximum period data may be retained?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Only as long as necessary for the purpose it was collected",
                isCorrect: true,
            },
            { id: "b", text: "Exactly 5 years", isCorrect: false },
            { id: "c", text: "Indefinitely", isCorrect: false },
            { id: "d", text: "10 years minimum", isCorrect: false },
        ],
        explanation: "POPIA requires that personal information be retained only for as long as necessary for the purpose for which it was collected or processed.",
        points: 5,
        categories: ["POPIA", "Data Protection", "Record Keeping"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 26,
        questionText: "What is the cooling-off period for long-term insurance policies?",
        questionType: "single",
        options: [
            { id: "a", text: "7 days", isCorrect: false },
            { id: "b", text: "14 days", isCorrect: false },
            { id: "c", text: "30 days", isCorrect: true },
            { id: "d", text: "60 days", isCorrect: false },
        ],
        explanation: "Long-term insurance policies have a 30-day cooling-off period during which the policyholder can cancel without penalty.",
        points: 5,
        categories: ["Consumer Protection", "Long-term Insurance", "Policy Rights"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 27,
        questionText: "Which of the following is NOT a principle of POPIA?",
        questionType: "single",
        options: [
            { id: "a", text: "Accountability", isCorrect: false },
            { id: "b", text: "Processing limitation", isCorrect: false },
            { id: "c", text: "Openness", isCorrect: false },
            { id: "d", text: "Profit maximization", isCorrect: true },
        ],
        explanation: "POPIA's eight principles include accountability, processing limitation, and openness, but not profit maximization.",
        points: 5,
        categories: ["POPIA", "Data Protection", "Compliance"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 28,
        questionText: "What is the minimum qualification required for a Category I FSP representative?",
        questionType: "single",
        options: [
            { id: "a", text: "Matric certificate", isCorrect: false },
            { id: "b", text: "RE5 examination", isCorrect: false },
            {
                id: "c",
                text: "RE5 and relevant product-specific examinations (e.g., RE 1 for LT Insurance)",
                isCorrect: true,
            },
            { id: "d", text: "University degree in finance", isCorrect: false },
        ],
        explanation: "Category I representatives must pass RE5 plus product-specific exams like RE1 for long-term insurance.",
        points: 5,
        categories: ["Licensing", "Qualifications", "FAIS Act"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 29,
        questionText: "Under TCF, who is ultimately responsible for ensuring fair treatment of customers?",
        questionType: "single",
        options: [
            { id: "a", text: "Individual advisors only", isCorrect: false },
            { id: "b", text: "The compliance officer", isCorrect: false },
            {
                id: "c",
                text: "The board and senior management of the FSP",
                isCorrect: true,
            },
            { id: "d", text: "The FSCA regulator", isCorrect: false },
        ],
        explanation: "TCF places primary responsibility on the board and senior management to embed fair treatment in the organizational culture.",
        points: 5,
        categories: ["TCF", "Governance", "Management Responsibility"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 30,
        questionText: "What is the purpose of a mandate agreement in financial services?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To define the scope of authority and responsibilities between the FSP and representative",
                isCorrect: true,
            },
            { id: "b", text: "To replace the need for licensing", isCorrect: false },
            { id: "c", text: "To set commission rates", isCorrect: false },
            { id: "d", text: "To bypass compliance requirements", isCorrect: false },
        ],
        explanation: "A mandate agreement clearly defines the authority, duties, and boundaries within which a representative operates under an FSP.",
        points: 5,
        categories: ["Organizational Structure", "FAIS Act", "Compliance"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 31,
        questionText: "Which body regulates short-term insurance in South Africa?",
        questionType: "single",
        options: [
            { id: "a", text: "South African Reserve Bank", isCorrect: false },
            {
                id: "b",
                text: "Financial Sector Conduct Authority (FSCA)",
                isCorrect: true,
            },
            { id: "c", text: "National Treasury", isCorrect: false },
            { id: "d", text: "Road Accident Fund", isCorrect: false },
        ],
        explanation: "The FSCA regulates market conduct for both short-term and long-term insurance.",
        points: 5,
        categories: ["Regulatory Bodies", "Short-term Insurance"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 32,
        questionText: "What is the primary difference between rendering financial advice and intermediary services?",
        questionType: "single",
        options: [
            { id: "a", text: "There is no difference", isCorrect: false },
            {
                id: "b",
                text: "Advice involves recommendations, while intermediary services involve execution or administration",
                isCorrect: true,
            },
            {
                id: "c",
                text: "Advice requires a license, intermediary services do not",
                isCorrect: false,
            },
            { id: "d", text: "Only advice incurs fees", isCorrect: false },
        ],
        explanation: "Financial advice involves making recommendations to clients, while intermediary services include actions like policy administration or claims processing.",
        points: 5,
        categories: ["FAIS Act", "Service Definition", "Licensing"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 33,
        questionText: "Under FICA, what does the term 'beneficial owner' refer to?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "The person who benefits from insurance claims",
                isCorrect: false,
            },
            {
                id: "b",
                text: "The natural person who ultimately owns or controls the client or on whose behalf a transaction is conducted",
                isCorrect: true,
            },
            { id: "c", text: "The insurance company", isCorrect: false },
            { id: "d", text: "The financial advisor", isCorrect: false },
        ],
        explanation: "A beneficial owner is the natural person who ultimately owns or controls a legal entity or on whose behalf a transaction is being conducted.",
        points: 5,
        categories: ["FICA", "Definitions", "KYC"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 34,
        questionText: "Which of the following would constitute churning in financial services?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Recommending unnecessary policy replacements to generate commission",
                isCorrect: true,
            },
            {
                id: "b",
                text: "Reviewing a client's portfolio annually",
                isCorrect: false,
            },
            {
                id: "c",
                text: "Providing detailed product comparisons",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Updating client information regularly",
                isCorrect: false,
            },
        ],
        explanation: "Churning is the unethical practice of encouraging unnecessary transactions primarily to generate commissions.",
        points: 5,
        categories: ["Ethics", "Misconduct", "Consumer Protection"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 35,
        questionText: "What is the purpose of the Policyholder Protection Rules (PPRs)?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To set minimum standards for treating policyholders fairly",
                isCorrect: true,
            },
            { id: "b", text: "To determine premium rates", isCorrect: false },
            { id: "c", text: "To license insurance agents", isCorrect: false },
            { id: "d", text: "To manage insurance claims", isCorrect: false },
        ],
        explanation: "PPRs establish minimum standards for fair treatment of policyholders throughout the product lifecycle.",
        points: 5,
        categories: ["Consumer Protection", "PPRs", "Long-term Insurance"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 36,
        questionText: "Under FAIS, what is the maximum fine for contravening the Act?",
        questionType: "single",
        options: [
            { id: "a", text: "R1 million", isCorrect: false },
            { id: "b", text: "R5 million", isCorrect: false },
            {
                id: "c",
                text: "R10 million or 10 years imprisonment",
                isCorrect: true,
            },
            { id: "d", text: "There are no criminal penalties", isCorrect: false },
        ],
        explanation: "Contraventions of FAIS can result in fines up to R10 million and/or imprisonment of up to 10 years.",
        points: 5,
        categories: ["FAIS Act", "Penalties", "Compliance"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 37,
        questionText: "What is the main purpose of a needs analysis in the insurance sales process?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To determine the client's financial situation and insurance requirements",
                isCorrect: true,
            },
            { id: "b", text: "To calculate commission", isCorrect: false },
            { id: "c", text: "To comply with tax regulations", isCorrect: false },
            { id: "d", text: "To set premium amounts", isCorrect: false },
        ],
        explanation: "A needs analysis identifies the client's financial situation, goals, and appropriate insurance coverage needed.",
        points: 5,
        categories: ["Needs Analysis", "Best Practices", "Client Onboarding"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 38,
        questionText: "Which TCF outcome addresses the importance of clear client communication?",
        questionType: "single",
        options: [
            { id: "a", text: "Outcome 2: Product design", isCorrect: false },
            {
                id: "b",
                text: "Outcome 3: Clear information and disclosure",
                isCorrect: true,
            },
            { id: "c", text: "Outcome 5: Product performance", isCorrect: false },
            { id: "d", text: "Outcome 6: Claims handling", isCorrect: false },
        ],
        explanation: "TCF Outcome 3 ensures that customers receive clear information before, during, and after the point of sale.",
        points: 5,
        categories: ["TCF", "Communication", "Disclosure"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 39,
        questionText: "What is the role of the Prudential Authority (PA)?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To supervise the safety and soundness of financial institutions",
                isCorrect: true,
            },
            { id: "b", text: "To regulate market conduct", isCorrect: false },
            { id: "c", text: "To handle consumer complaints", isCorrect: false },
            { id: "d", text: "To set interest rates", isCorrect: false },
        ],
        explanation: "The Prudential Authority supervises banks, insurers, and other financial institutions to ensure their financial soundness and stability.",
        points: 5,
        categories: ["Regulatory Bodies", "Twin Peaks", "Financial Stability"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 40,
        questionText: "Under the Twin Peaks model of financial regulation, what are the two peaks?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "Banks and insurance companies",
                isCorrect: false,
            },
            {
                id: "b",
                text: "Prudential Authority (PA) and Financial Sector Conduct Authority (FSCA)",
                isCorrect: true,
            },
            {
                id: "c",
                text: "SARB and National Treasury",
                isCorrect: false,
            },
            { id: "d", text: "FSPs and consumers", isCorrect: false },
        ],
        explanation: "The Twin Peaks model separates prudential regulation (PA) from market conduct regulation (FSCA).",
        points: 5,
        categories: ["Regulatory Framework", "Twin Peaks", "Regulatory Bodies"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 41,
        questionText: "What is the primary purpose of disclosure under the FAIS Act?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To inform clients of potential conflicts of interest and how the FSP is remunerated",
                isCorrect: true,
            },
            { id: "b", text: "To advertise products", isCorrect: false },
            { id: "c", text: "To collect personal information", isCorrect: false },
            { id: "d", text: "To avoid paying taxes", isCorrect: false },
        ],
        explanation: "Disclosure ensures transparency about potential conflicts of interest and remuneration structures.",
        points: 5,
        categories: ["FAIS Act", "Disclosure", "Transparency"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 42,
        questionText: "Which of the following transactions would trigger Enhanced Due Diligence under FICA?",
        questionType: "multiple",
        options: [
            {
                id: "a",
                text: "Transactions involving a Politically Exposed Person (PEP)",
                isCorrect: true,
            },
            {
                id: "b",
                text: "Cross-border transactions to high-risk jurisdictions",
                isCorrect: true,
            },
            {
                id: "c",
                text: "Regular pension contributions",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Transactions where the source of funds is unclear",
                isCorrect: true,
            },
        ],
        explanation: "EDD is required for PEPs, high-risk jurisdictions, and transactions with unclear fund sources.",
        points: 5,
        categories: ["FICA", "Risk Management", "EDD"],
        difficulty: "advanced",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 43,
        questionText: "What is the consequence of failing to complete mandatory CPD requirements?",
        questionType: "single",
        options: [
            { id: "a", text: "No consequences", isCorrect: false },
            { id: "b", text: "Only a warning letter", isCorrect: false },
            {
                id: "c",
                text: "Potential suspension or withdrawal of recognition",
                isCorrect: true,
            },
            { id: "d", text: "Automatic license renewal anyway", isCorrect: false },
        ],
        explanation: "Failure to meet CPD requirements can result in suspension or loss of recognition to provide financial services.",
        points: 5,
        categories: ["Professional Development", "CPD", "Compliance"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 44,
        questionText: "Under POPIA, what must an organization do before collecting personal information?",
        questionType: "multiple",
        options: [
            {
                id: "a",
                text: "Obtain consent from the data subject",
                isCorrect: true,
            },
            {
                id: "b",
                text: "Inform the data subject of the purpose of collection",
                isCorrect: true,
            },
            { id: "c", text: "Pay a collection fee", isCorrect: false },
            {
                id: "d",
                text: "Ensure collection is lawful and reasonable",
                isCorrect: true,
            },
        ],
        explanation: "POPIA requires consent, purpose notification, and ensures collection is lawful and reasonable.",
        points: 5,
        categories: ["POPIA", "Data Protection", "Consent"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 45,
        questionText: "What is the difference between a tied agent and an independent broker?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "A tied agent represents one insurer, while an independent broker represents multiple insurers",
                isCorrect: true,
            },
            {
                id: "b",
                text: "There is no difference",
                isCorrect: false,
            },
            {
                id: "c",
                text: "Tied agents are not regulated by FAIS",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Independent brokers cannot earn commission",
                isCorrect: false,
            },
        ],
        explanation: "A tied agent is contracted to represent one insurer, while an independent broker can offer products from multiple insurers.",
        points: 5,
        categories: ["FAIS Act", "Broker Types", "Industry Structure"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 46,
        questionText: "Which of the following is a red flag for potential money laundering?",
        questionType: "multiple",
        options: [
            {
                id: "a",
                text: "Client reluctant to provide identification",
                isCorrect: true,
            },
            {
                id: "b",
                text: "Frequent policy cancellations within cooling-off period",
                isCorrect: true,
            },
            {
                id: "c",
                text: "Consistent monthly premium payments",
                isCorrect: false,
            },
            {
                id: "d",
                text: "Large cash deposits without clear source",
                isCorrect: true,
            },
        ],
        explanation: "Red flags include reluctance to provide ID, frequent cancellations, and unexplained cash deposits.",
        points: 5,
        categories: ["Anti-Money Laundering", "FICA", "Risk Indicators"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 47,
        questionText: "What is the maximum period for submitting a complaint to the Ombud after becoming aware of the issue?",
        questionType: "single",
        options: [
            { id: "a", text: "3 months", isCorrect: false },
            { id: "b", text: "6 months", isCorrect: true },
            { id: "c", text: "1 year", isCorrect: false },
            { id: "d", text: "3 years", isCorrect: false },
        ],
        explanation: "Complaints must be submitted to the Ombud within 6 months of the FSP's final response or becoming aware of the issue.",
        points: 5,
        categories: ["Complaints Management", "Ombud", "Timeframes"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 48,
        questionText: "Which principle of insurance requires full disclosure of all material facts?",
        questionType: "single",
        options: [
            { id: "a", text: "Insurable interest", isCorrect: false },
            { id: "b", text: "Utmost good faith (uberrima fides)", isCorrect: true },
            { id: "c", text: "Indemnity", isCorrect: false },
            { id: "d", text: "Subrogation", isCorrect: false },
        ],
        explanation: "The principle of utmost good faith requires both parties to disclose all material facts honestly.",
        points: 5,
        categories: ["Insurance Principles", "Ethics", "Legal Principles"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 49,
        questionText: "Under TCF, what is meant by 'product lifecycle'?",
        questionType: "single",
        options: [
            { id: "a", text: "The warranty period of the product", isCorrect: false },
            {
                id: "b",
                text: "All stages from product design, marketing, sale, administration to claims and termination",
                isCorrect: true,
            },
            { id: "c", text: "Only the sales process", isCorrect: false },
            { id: "d", text: "The policy term duration", isCorrect: false },
        ],
        explanation: "TCF applies throughout the entire product lifecycle, from design through to post-sale servicing and claims.",
        points: 5,
        categories: ["TCF", "Product Management", "Consumer Protection"],
        difficulty: "intermediate",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
    {
        questionNumber: 50,
        questionText: "What is the primary purpose of the Financial Intelligence Centre?",
        questionType: "single",
        options: [
            {
                id: "a",
                text: "To combat money laundering and terrorist financing",
                isCorrect: true,
            },
            { id: "b", text: "To regulate financial markets", isCorrect: false },
            { id: "c", text: "To provide investment advice", isCorrect: false },
            { id: "d", text: "To manage government budgets", isCorrect: false },
        ],
        explanation: "The FIC is South Africa's national center for combating money laundering, terrorist financing, and proliferation financing.",
        points: 5,
        categories: ["FICA", "Regulatory Bodies", "Anti-Money Laundering"],
        difficulty: "beginner",
        tierAccess: ["free"], // FREE TIER ONLY
        isFreeQuestion: true,
    },
];
async function deleteAllQuestionsAndExams() {
    console.log("🗑️  Deleting all existing exams and questions...");
    try {
        // Scan for all exam items
        const scanCommand = new lib_dynamodb_1.ScanCommand({
            TableName: TABLE_NAME,
            FilterExpression: "begins_with(PK, :examPrefix)",
            ExpressionAttributeValues: {
                ":examPrefix": "EXAM#",
            },
        });
        const result = await docClient.send(scanCommand);
        if (result.Items && result.Items.length > 0) {
            console.log(`Found ${result.Items.length} items to delete`);
            // Delete each item
            for (const item of result.Items) {
                console.log(`Deleting: ${item["PK"]} - ${item["SK"]}`);
                const deleteCommand = new lib_dynamodb_1.DeleteCommand({
                    TableName: TABLE_NAME,
                    Key: {
                        PK: item["PK"],
                        SK: item["SK"],
                    },
                });
                await docClient.send(deleteCommand);
            }
            console.log("✅ All existing exams and questions deleted");
        }
        else {
            console.log("No existing exams or questions found");
        }
    }
    catch (error) {
        console.error("Error deleting existing data:", error);
        throw error;
    }
}
async function createExam() {
    console.log("📝 Creating exam metadata...");
    try {
        const command = new lib_dynamodb_1.PutCommand({
            TableName: TABLE_NAME,
            Item: examMetadata,
        });
        await docClient.send(command);
        console.log("✅ Exam metadata created");
    }
    catch (error) {
        console.error("Error creating exam:", error);
        throw error;
    }
}
async function createQuestions() {
    console.log("📝 Creating questions...");
    for (const question of questions) {
        const questionId = `q${question.questionNumber
            .toString()
            .padStart(3, "0")}`;
        const questionItem = {
            PK: `EXAM#${EXAM_ID}`,
            SK: `QUESTION#${questionId}`,
            questionId,
            questionNumber: question.questionNumber,
            questionText: question.questionText,
            questionType: question.questionType,
            options: question.options,
            explanation: question.explanation,
            points: question.points,
            categories: question.categories,
            difficulty: question.difficulty,
            examId: EXAM_ID,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            entityType: "QUESTION",
        };
        try {
            const command = new lib_dynamodb_1.PutCommand({
                TableName: TABLE_NAME,
                Item: questionItem,
            });
            await docClient.send(command);
            console.log(`✅ Question ${question.questionNumber} created: ${question.questionText.substring(0, 50)}...`);
        }
        catch (error) {
            console.error(`Error creating question ${question.questionNumber}:`, error);
            throw error;
        }
    }
    console.log("✅ All questions created");
}
async function main() {
    console.log("🚀 Starting RE5 Exam Seed Script");
    console.log(`📊 Table: ${TABLE_NAME}`);
    console.log(`📋 Exam ID: ${EXAM_ID}`);
    console.log("");
    try {
        // Step 1: Delete all existing data
        await deleteAllQuestionsAndExams();
        console.log("");
        // Step 2: Create exam metadata
        await createExam();
        console.log("");
        // Step 3: Create questions
        await createQuestions();
        console.log("");
        console.log("🎉 Seed script completed successfully!");
        console.log("");
        console.log("📊 Summary:");
        console.log(`   - Exam created: ${examMetadata.title}`);
        console.log(`   - Total questions: ${questions.length}`);
        console.log(`   - Exam duration: ${examMetadata.totalTime / 60} minutes`);
        console.log(`   - Passing score: ${examMetadata.passingScore}%`);
        console.log("");
        console.log("✨ You can now navigate to /exam/re5-full-exam/start to view the exam");
    }
    catch (error) {
        console.error("❌ Script failed:", error);
        process.exit(1);
    }
}
main();
